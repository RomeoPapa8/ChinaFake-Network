const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// serve your website
app.use(express.static("public"));

// realtime chat
io.on("connection", (socket) => {
  console.log("user connected");

  socket.on("chat message", (msg) => {
    io.emit("chat message", msg);
  });

  socket.on("disconnect", () => {
    console.log("user disconnected");
  });
});

// IMPORTANT: required for hosting platforms like Render
const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
  console.log("server running on port " + PORT);
});